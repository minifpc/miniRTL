This is a placeholder for TinyRTL.<br>
Fully based on pre-working tasks by @fibonacci.<br>

Currently, it will be used for private use by @fibodev and @paule32 for minimize the code base of FPC Application's.

![Alpha Tool preview](tools/img/screen000.png)