PASCALMAIN:

; --- Prolog ---
print_line_1:
push    rbp
mov     rbp, rsp

; -------------------------------------------------------------------
; 64 Bytes reservieren:
;  - 32 B Shadow Space (Pflicht als Caller vor jedem call)
;  - 32 B "lokal" (hier ungenutzt, dient auch dem Alignment)
; Nach push rbp ist rsp 16-Byte aligned; 64 h�lt das Alignment.
; -------------------------------------------------------------------
sub     rsp, 64

; --- Aufruf von printf(fmt, a, b) ---
; -------------------------------------------------------------------
; MS x64-ABI: RCX, RDX, R8, R9 = die ersten 4 Integer/Pointer-Args
; F�r variadische Funktionen (printf): AL = Anzahl der XMM-Args -> 0
; -------------------------------------------------------------------
lea     rcx, [rel fmtHello]    ; 1. Arg: Format-String
xor     eax, eax               ; AL=0 (keine FP/XMM-Args)
CALL_IAT  printf                 ; Shadow Space liegt bei [rsp..rsp+31]

; --- R�ckgabewert von main (int) ---
xor     eax, eax               ; return 0

; --- Epilog ---
add     rsp, 64
pop     rbp
ret
