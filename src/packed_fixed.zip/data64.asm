
times (DATA_RAW_PTR-($-$$)) db 0
data_start:
%include 'data.inc'
errA: db 'MessageBoxW failed',0
capA: db 'User32',0
msgW: WSTR 'Hello World'
capW: WSTR 'Pure NASM PE-64'
data_end:
times (ALIGN_UP($-$$,FILEALIGN)-($-$$)) db 0
