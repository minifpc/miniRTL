
# Qt5 Satzanalyse (Python, PyQt5)

## Installation
```bash
pip install PyQt5 matplotlib pandas
```

Lege die Wörterbuch-CSV `de_woerterbuch_rund3000.csv` in dieses Verzeichnis oder wähle sie im GUI über **„Wörterbuch laden…“** aus.
Optional kannst du `satz_analyse_config.json` daneben legen, um Regeln anzupassen.

## Start
```bash
python main.py
```

## Hinweise
- Farbliche Markierungen:
  - Rot: unbekannte Wörter
  - Orange: Groß-/Kleinschreibung (Heuristik)
  - Blau: feste Wendungen
  - Lila: Verb-2-Heuristik
  - Magenta: doppelte Negation
  - Violett: Konjunktionsdopplung
  - Grau: Komma-Hinweis (nur in der Übersicht)
  - Grün: erkannte Flexionsformen (Verb/Nomen)
- Rechtsklick/Tooltip über markierten Bereichen zeigt eine Kurzinfo.
